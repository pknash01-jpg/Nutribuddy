
export default function Home() {
  return (
    <main style={{
      fontFamily: "Arial",
      background: "#f8fafc",
      color: "#0f172a",
      minHeight: "100vh",
      padding: "40px"
    }}>
      <section style={{maxWidth:"1200px",margin:"0 auto"}}>

        <nav style={{
          display:"flex",
          justifyContent:"space-between",
          alignItems:"center",
          marginBottom:"60px"
        }}>
          <h1 style={{fontSize:"34px",color:"#16a34a"}}>
            NutriBuddy
          </h1>

          <button style={{
            background:"#16a34a",
            color:"white",
            border:"none",
            padding:"12px 20px",
            borderRadius:"12px"
          }}>
            Get Started
          </button>
        </nav>

        <h1 style={{
          fontSize:"64px",
          lineHeight:"1.1"
        }}>
          Your AI Weight Loss Buddy
        </h1>

        <p style={{
          fontSize:"22px",
          opacity:"0.7",
          maxWidth:"700px"
        }}>
          Smart calorie tracking, AI recipes, wearable sync,
          and wellness coaching.
        </p>

      </section>
    </main>
  )
}
