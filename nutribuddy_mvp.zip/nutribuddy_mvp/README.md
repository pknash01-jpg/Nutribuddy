
# NutriBuddy MVP

AI-powered nutrition and wellness platform.
